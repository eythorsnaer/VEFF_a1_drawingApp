# Vefforritun
Verkefni 1

TODO: 

1.  Setja border á canvas KOMIÐ
2.  Passa að canvasinn hreinsist ekki eftir að lína er teiknuð KOMIÐ
3.  Teikna circle KOMIÐ
4.  Teikna rectangle KOMIÐ
5.  Teikna line KOMIÐ
6.  Teikna text SJOMLI
7.  Teikna pen (i.e. a freehand drawing) (á að vera default) KOMIÐ
8.  Breyta lit KOMIÐ
9.  Breyta font
10. Breyta punktastærð
11. Hægt að skipta milli stroke og fill fyrir aukastig? KOMIÐ
12. Implementa undo og redo
13. Gera teiknað stöff hreyfanlegt
14. Passa að það sé hægt að save-a og load-a
